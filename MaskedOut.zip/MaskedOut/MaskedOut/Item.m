//
//  Item.m
//  MaskedOut
//
//  Created by nizar cherkaoui on 12/12/13.
//  Copyright (c) 2013 nizar cherkaoui. All rights reserved.
//

#import "Item.h"


@implementation Item

@dynamic dateTime;
@dynamic name;
@dynamic outputFileURL;
@dynamic selectedMask;

@end
